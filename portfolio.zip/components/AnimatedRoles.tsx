"use client"

import { useEffect, useState } from "react"

const AnimatedRoles = () => {
  const roles = ["Aspiring Data Engineer", "Full-stack Developer"]
  const [currentRole, setCurrentRole] = useState(0)
  const [currentWord, setCurrentWord] = useState(0)
  const [displayText, setDisplayText] = useState("")
  const [isDeleting, setIsDeleting] = useState(false)

  useEffect(() => {
    const role = roles[currentRole]
    const words = role.split(" ")

    const timer = setTimeout(
      () => {
        if (!isDeleting) {
          // Adding words
          if (currentWord < words.length) {
            setDisplayText((prev) => prev + (prev ? " " : "") + words[currentWord])
            setCurrentWord((prev) => prev + 1)
          } else {
            // Wait before deleting
            setTimeout(() => {
              setIsDeleting(true)
            }, 1500)
          }
        } else {
          // Deleting words
          if (currentWord > 0) {
            const newWords = words.slice(0, currentWord - 1)
            setDisplayText(newWords.join(" "))
            setCurrentWord((prev) => prev - 1)
          } else {
            setIsDeleting(false)
            setCurrentRole((prev) => (prev + 1) % roles.length)
          }
        }
      },
      isDeleting ? 150 : 300,
    )

    return () => clearTimeout(timer)
  }, [currentRole, currentWord, isDeleting])

  return (
    <div className="h-12">
      <h2 className="text-2xl font-medium text-primary">
        {displayText}
        <span className="ml-1 inline-block h-6 w-1 animate-blink bg-primary"></span>
      </h2>
    </div>
  )
}

export default AnimatedRoles

