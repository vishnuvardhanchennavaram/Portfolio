import Image from "next/image"
import { ArrowRight } from "lucide-react"
import { Button } from "@/components/ui/button"

const AboutSection = () => {
  return (
    <section id="about" className="py-8 md:py-12">
      <h2 className="mb-8 text-3xl font-bold tracking-tight">About Me</h2>
      <div className="grid gap-8 md:grid-cols-2">
        <div className="flex items-center justify-center">
          <div className="relative h-80 w-80 overflow-hidden rounded-full border-4 border-primary shadow-lg">
            <Image
              src="/images/profile.png"
              alt="Vishnuvardhan Chennavaram"
              width={320}
              height={320}
              className="object-cover"
            />
          </div>
        </div>
        <div className="flex flex-col justify-center">
          <p className="mb-4 text-lg text-muted-foreground">
            I am a passionate technologist with expertise in data engineering and full-stack development. With a strong
            foundation in both backend and frontend technologies, I create data-driven applications that deliver
            meaningful insights and exceptional user experiences.
          </p>
          <p className="mb-6 text-lg text-muted-foreground">
            My journey in technology has equipped me with a diverse skill set spanning database design, ETL processes,
            API development, and modern frontend frameworks.
          </p>
          <Button className="w-fit">
            Download Resume <ArrowRight className="ml-2 h-4 w-4" />
          </Button>
        </div>
      </div>
    </section>
  )
}

export default AboutSection

