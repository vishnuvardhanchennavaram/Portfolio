import type React from "react"
import { Github, Linkedin, Mail } from "lucide-react"
import ContactForm from "@/components/ui/ContactForm"

const ContactSection = () => {
  return (
    <section id="contact" className="py-8 md:py-12">
      <h2 className="mb-8 text-3xl font-bold tracking-tight">Contact Me</h2>
      <div className="grid gap-8 md:grid-cols-2">
        <div>
          <p className="mb-4 text-lg text-muted-foreground">
            I'm always open to discussing new projects, opportunities, or partnerships. Feel free to reach out to me
            using the contact form or through my social media profiles.
          </p>
          <div className="space-y-4">
            <ContactLink
              href="mailto:chennavaram.v@northeastern.edu"
              icon={<Mail className="h-5 w-5 text-primary" />}
              text="chennavaram.v@northeastern.edu"
            />
            <ContactLink
              href="https://www.linkedin.com/in/vishnuvardhan-chennavaram"
              icon={<Linkedin className="h-5 w-5 text-primary" />}
              text="linkedin.com/in/vishnuvardhan-chennavaram"
            />
            <ContactLink
              href="https://github.com/vishnuvardhanchennavaram"
              icon={<Github className="h-5 w-5 text-primary" />}
              text="github.com/vishnuvardhanchennavaram"
            />
          </div>
        </div>
        <ContactForm />
      </div>
    </section>
  )
}

interface ContactLinkProps {
  href: string
  icon: React.ReactNode
  text: string
}

const ContactLink = ({ href, icon, text }: ContactLinkProps) => {
  return (
    <div className="flex items-center gap-2">
      {icon}
      <a href={href} target="_blank" rel="noopener noreferrer" className="hover:text-primary transition-colors">
        {text}
      </a>
    </div>
  )
}

export default ContactSection

