import SkillCard from "@/components/ui/SkillCard"

const SkillsSection = () => {
  const skillCategories = [
    {
      id: 1,
      title: "Data Engineering",
      skills: ["ETL/ELT Pipelines", "SQL & NoSQL Databases", "Data Warehousing", "Apache Spark"],
    },
    {
      id: 2,
      title: "Backend Development",
      skills: ["Python", "Node.js", "RESTful APIs", "Microservices"],
    },
    {
      id: 3,
      title: "Frontend Development",
      skills: ["React", "Next.js", "Tailwind CSS", "TypeScript"],
    },
  ]

  return (
    <section id="skills" className="py-8 md:py-12">
      <h2 className="mb-8 text-3xl font-bold tracking-tight">Skills</h2>
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {skillCategories.map((category) => (
          <SkillCard key={category.id} title={category.title} skills={category.skills} />
        ))}
      </div>
    </section>
  )
}

export default SkillsSection

