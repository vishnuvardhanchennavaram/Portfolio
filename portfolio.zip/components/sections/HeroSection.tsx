"use client"

import type React from "react"

import { Github, Linkedin, Mail } from "lucide-react"
import { Button } from "@/components/ui/button"
import AnimatedRoles from "@/components/AnimatedRoles"

const HeroSection = () => {
  return (
    <section id="home" className="py-8 md:py-12">
      <div className="flex flex-col items-start gap-4">
        <h1 className="text-4xl font-bold tracking-tight sm:text-5xl md:text-6xl">
          Hi, I&apos;m Vishnuvardhan Chennavaram
        </h1>
        <AnimatedRoles />
        <div className="flex gap-4">
          <SocialButton
            href="https://github.com/vishnuvardhanchennavaram"
            icon={<Github className="h-4 w-4" />}
            label="GitHub"
          />
          <SocialButton
            href="https://www.linkedin.com/in/vishnuvardhan-chennavaram"
            icon={<Linkedin className="h-4 w-4" />}
            label="LinkedIn"
          />
          <SocialButton
            href="mailto:chennavaram.v@northeastern.edu"
            icon={<Mail className="h-4 w-4" />}
            label="Email"
          />
        </div>
      </div>
    </section>
  )
}

interface SocialButtonProps {
  href: string
  icon: React.ReactNode
  label: string
}

const SocialButton = ({ href, icon, label }: SocialButtonProps) => {
  return (
    <Button variant="outline" size="icon" asChild>
      <a href={href} target="_blank" rel="noopener noreferrer">
        {icon}
        <span className="sr-only">{label}</span>
      </a>
    </Button>
  )
}

export default HeroSection

