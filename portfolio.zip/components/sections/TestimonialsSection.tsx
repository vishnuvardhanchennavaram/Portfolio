import TestimonialCard from "@/components/ui/TestimonialCard"

const TestimonialsSection = () => {
  const testimonials = [
    {
      id: 1,
      content:
        "Vishnuvardhan Chennavaram played a pivotal role in optimizing our data infrastructure. Their deep understanding of ETL pipelines, database management, and cloud integration helped us achieve faster data processing and more reliable analytics. They bring both technical excellence and a collaborative mindset to the team.",
      author: "Emily Davis",
      role: "Senior Data Engineer, HCL Technologies",
      image: "/images/testimonials/emily-davis.jpeg",
    },
    {
      id: 2,
      content:
        "Working with Vishnuvardhan Chennavaram was an absolute game-changer for our development team. Their expertise in both front-end and back-end technologies brought our web application to life with seamless functionality and a clean, user-friendly interface. Their problem-solving skills and proactive communication made every sprint smooth and successful.",
      author: "Michael Brown",
      role: "Product Manager, TechStart Solutions",
      image: "/images/testimonials/michael-brown.jpeg",
    },
  ]

  return (
    <section id="testimonials" className="py-8 md:py-12">
      <h2 className="mb-8 text-3xl font-bold tracking-tight">Testimonials</h2>
      <div className="grid gap-6 md:grid-cols-2">
        {testimonials.map((testimonial) => (
          <TestimonialCard
            key={testimonial.id}
            content={testimonial.content}
            author={testimonial.author}
            role={testimonial.role}
            image={testimonial.image}
          />
        ))}
      </div>
    </section>
  )
}

export default TestimonialsSection

