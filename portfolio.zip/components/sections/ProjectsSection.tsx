import ProjectCard from "@/components/ui/ProjectCard"

const ProjectsSection = () => {
  const projects = [
    {
      id: 1,
      title: "8 Dollar Meal - A Food Delivery Website",
      description:
        "Dynamic Role-Based Dashboards: Developed a React application with role-specific dashboards for Admins, Customers, and Delivery Partners, featuring functionalities like table reservations, order management, and checkout with payment gateway integration.",
      image: "/images/projects/8-dollar-meal.jpeg",
      technologies: ["Node.js", "React", "MongoDB", "REST API"],
    },
    {
      id: 2,
      title: "Library Management System",
      description:
        "The Library Management System is a digital solution designed to streamline book tracking, member management, and borrowing/return operations. Built using Python for backend logic, SQL for database management, and Power BI for data visualization, the system ensures efficient handling of library resources and insightful reporting on usage trends.",
      image: "/images/projects/library-management.jpeg",
      technologies: ["Python", "SQL", "PowerBI"],
    },
    {
      id: 3,
      title: "Health Care System",
      description:
        "Custom Dashboards: Designed tailored dashboards for Admins, Customers, and Delivery Partners to streamline workflows and enhance user interaction. Integrated Authentication and Navigation: Developed secure user login and registration systems with React Router for dynamic route management.",
      image: "/images/projects/healthcare-system.png",
      technologies: ["Java", "Node.js", "React", "AWS", "PostgreSQL"],
    },
  ]

  return (
    <section id="projects" className="py-8 md:py-12">
      <h2 className="mb-8 text-3xl font-bold tracking-tight">Projects</h2>
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {projects.map((project) => (
          <ProjectCard
            key={project.id}
            title={project.title}
            description={project.description}
            image={project.image}
            technologies={project.technologies}
          />
        ))}
      </div>
    </section>
  )
}

export default ProjectsSection

