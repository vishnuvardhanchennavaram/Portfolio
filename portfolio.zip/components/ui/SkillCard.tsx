interface SkillCardProps {
  title: string
  skills: string[]
}

const SkillCard = ({ title, skills }: SkillCardProps) => {
  return (
    <div className="skill-card rounded-lg border bg-white p-6 transition-all hover:border-primary hover:shadow-lg">
      <h3 className="mb-4 text-xl font-bold">{title}</h3>
      <ul className="space-y-2">
        {skills.map((skill, index) => (
          <li key={index} className="flex items-center gap-2">
            <div className="h-2 w-2 rounded-full bg-primary"></div>
            <span>{skill}</span>
          </li>
        ))}
      </ul>
    </div>
  )
}

export default SkillCard

