import Image from "next/image"

interface ProjectCardProps {
  title: string
  description: string
  image: string
  technologies: string[]
}

const ProjectCard = ({ title, description, image, technologies }: ProjectCardProps) => {
  return (
    <div className="group rounded-lg border bg-white p-6 transition-all hover:border-primary hover:shadow-lg">
      <div className="mb-4 aspect-video w-full overflow-hidden rounded-md">
        <Image
          src={image || "/placeholder.svg"}
          alt={title}
          width={600}
          height={340}
          className="h-full w-full object-cover transition-transform group-hover:scale-105"
        />
      </div>
      <h3 className="mb-2 text-xl font-bold">{title}</h3>
      <p className="mb-4 text-muted-foreground">{description}</p>
      <div className="flex flex-wrap gap-2">
        {technologies.map((tech, index) => (
          <span key={index} className="rounded-full bg-primary/10 px-3 py-1 text-xs text-primary">
            {tech}
          </span>
        ))}
      </div>
    </div>
  )
}

export default ProjectCard

