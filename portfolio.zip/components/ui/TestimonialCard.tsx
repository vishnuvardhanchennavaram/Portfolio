import Image from "next/image"

interface TestimonialCardProps {
  content: string
  author: string
  role: string
  image: string
}

const TestimonialCard = ({ content, author, role, image }: TestimonialCardProps) => {
  return (
    <div className="rounded-lg border bg-white p-6 transition-all hover:shadow-md">
      <p className="mb-4 italic text-muted-foreground">"{content}"</p>
      <div className="flex items-center gap-4">
        <div className="h-12 w-12 overflow-hidden rounded-full">
          <Image
            src={image || "/placeholder.svg"}
            alt={author}
            width={48}
            height={48}
            className="h-full w-full object-cover"
          />
        </div>
        <div>
          <h4 className="font-bold">{author}</h4>
          <p className="text-sm text-muted-foreground">{role}</p>
        </div>
      </div>
    </div>
  )
}

export default TestimonialCard

