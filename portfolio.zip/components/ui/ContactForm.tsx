import { Button } from "@/components/ui/button"

const ContactForm = () => {
  return (
    <form className="space-y-4 rounded-lg border bg-white p-6 shadow-sm">
      <div className="grid gap-4 md:grid-cols-2">
        <div className="space-y-2">
          <label htmlFor="name" className="text-sm font-medium">
            Name
          </label>
          <input
            id="name"
            className="w-full rounded-md border border-input bg-background px-3 py-2"
            placeholder="Your name"
          />
        </div>
        <div className="space-y-2">
          <label htmlFor="email" className="text-sm font-medium">
            Email
          </label>
          <input
            id="email"
            type="email"
            className="w-full rounded-md border border-input bg-background px-3 py-2"
            placeholder="Your email"
          />
        </div>
      </div>
      <div className="space-y-2">
        <label htmlFor="subject" className="text-sm font-medium">
          Subject
        </label>
        <input
          id="subject"
          className="w-full rounded-md border border-input bg-background px-3 py-2"
          placeholder="Subject"
        />
      </div>
      <div className="space-y-2">
        <label htmlFor="message" className="text-sm font-medium">
          Message
        </label>
        <textarea
          id="message"
          rows={5}
          className="w-full rounded-md border border-input bg-background px-3 py-2"
          placeholder="Your message"
        ></textarea>
      </div>
      <Button className="w-full">Send Message</Button>
    </form>
  )
}

export default ContactForm

