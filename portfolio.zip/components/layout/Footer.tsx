import type React from "react"
import { Github, Linkedin, Mail } from "lucide-react"
import { Button } from "@/components/ui/button"

const Footer = () => {
  const currentYear = new Date().getFullYear()

  return (
    <footer className="border-t bg-white py-6">
      <div className="container flex flex-col items-center justify-between gap-4 md:flex-row">
        <p className="text-center text-sm text-muted-foreground">
          © {currentYear} Vishnuvardhan Chennavaram. All rights reserved.
        </p>
        <div className="flex gap-4">
          <SocialButton
            href="https://github.com/vishnuvardhanchennavaram"
            icon={<Github className="h-4 w-4" />}
            label="GitHub"
          />
          <SocialButton
            href="https://www.linkedin.com/in/vishnuvardhan-chennavaram"
            icon={<Linkedin className="h-4 w-4" />}
            label="LinkedIn"
          />
          <SocialButton
            href="mailto:chennavaram.v@northeastern.edu"
            icon={<Mail className="h-4 w-4" />}
            label="Email"
          />
        </div>
      </div>
    </footer>
  )
}

interface SocialButtonProps {
  href: string
  icon: React.ReactNode
  label: string
}

const SocialButton = ({ href, icon, label }: SocialButtonProps) => {
  return (
    <Button variant="ghost" size="icon" asChild>
      <a href={href} target="_blank" rel="noopener noreferrer">
        {icon}
        <span className="sr-only">{label}</span>
      </a>
    </Button>
  )
}

export default Footer

