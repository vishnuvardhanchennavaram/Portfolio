import type React from "react"

const Navbar = () => {
  return (
    <header className="sticky top-0 z-40 w-full border-b bg-white/90 backdrop-blur">
      <div className="container flex h-16 items-center justify-between">
        <div className="logo-container">
          <a href="#home" className="block">
            <div className="logo-animation flex h-10 w-10 items-center justify-center rounded-lg bg-gradient-to-r from-blue-500 to-indigo-600 text-xl font-bold text-white shadow-md">
              VC
            </div>
          </a>
        </div>
        <nav className="flex items-center gap-6">
          <NavLink href="#about">About</NavLink>
          <NavLink href="#projects">Projects</NavLink>
          <NavLink href="#skills">Skills</NavLink>
          <NavLink href="#testimonials">Testimonials</NavLink>
          <NavLink href="#contact">Contact</NavLink>
        </nav>
      </div>
    </header>
  )
}

const NavLink = ({ href, children }: { href: string; children: React.ReactNode }) => {
  return (
    <a href={href} className="text-sm font-medium transition-colors hover:text-primary">
      {children}
    </a>
  )
}

export default Navbar

